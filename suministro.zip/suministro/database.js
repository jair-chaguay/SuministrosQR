const mysql = require('mysql2');

const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'datos',
    port: 3307
});

connection.connect((err)=>{
    if(err){
        console.error('Error en la base', err);
        return;
    }
    console.log('Conexion exitosa a MYSQL')
});

module.exports = connection;